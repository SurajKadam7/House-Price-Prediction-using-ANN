package main

import (
	"net/http"
	"github.com/surajkadam7/golang_microservice/broker-service/cmd/utils"

)

type Services struct{}



func (app *Services) Broker(w http.ResponseWriter, r *http.Request) {


	payload := utils.JsonResponseSchema{
		Error:   false,
		Message: "working",
		Data:    "hello",
	}


	json := utils.Json{
		Data: payload,
		Status: 202,
	}

	json.WriteJSON(w)
}
