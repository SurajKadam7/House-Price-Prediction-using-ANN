package main

import (
	"fmt"
	"log"
	"net/http"
)

const PORT = "8080"

type Config struct {
	middleware Middlewares
	services   Services
}

func main() {
	app := Config{}

	app.routes()
	srv := &http.Server{
		Addr:    fmt.Sprintf(":%s", PORT),
		Handler: nil,
	}
	log.Fatal(srv.ListenAndServe())
}
