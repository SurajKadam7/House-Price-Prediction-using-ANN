package main

import "net/http"


func addMiddlewares(f http.HandlerFunc, middlewares ...Middleware) http.HandlerFunc{
	for _, m := range middlewares{
		f = m(f)
	}
	return f
}


func (app *Config) routes(){
	
	http.HandleFunc("/broker", addMiddlewares(app.services.Broker, app.middleware.CORS))

}
