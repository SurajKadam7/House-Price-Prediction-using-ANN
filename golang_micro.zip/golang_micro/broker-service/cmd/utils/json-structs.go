package utils

import "net/http"


type Json struct{
	Data 				any
	Status 				int
	Headers 			[]http.Header
	Err					error
}

type JsonResponseSchema struct {
	Error   bool   `json:"error"`
	Message string `json:"message"`
	Data    any    `json:"data,omitempty"`
}

type DbSchema struct {
	DB   string `json:"db"`
	Name string `json:"name"`
}






